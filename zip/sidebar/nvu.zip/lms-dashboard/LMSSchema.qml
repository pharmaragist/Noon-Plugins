import qs.common.utils

JsonAdapter {
    property var materials: ({})
    property var schedule: ({})
    property var grades: ({})
    property var questions: ({})
    property int currentPage: 0
    property string questionsSelectedSubject: ""
}
